function MoveError (msg) {
  this.msg = msg;
}

module.exports = MoveError;
