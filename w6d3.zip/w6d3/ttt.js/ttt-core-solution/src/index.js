module.exports = {
  Board: require("./board"),
  Game: require("./game"),
  MoveError: require("./moveError")
};
