PostApp.Views.PostShow = Backbone.View.extend({
  template: JST["posts/show"]
});
