PostApp.Views.PostForm = Backbone.View.extend({
  tagName: 'form',
  template: JST["posts/form"]
});
