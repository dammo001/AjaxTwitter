PostApp.Models.Post = Backbone.Model.extend({
});
