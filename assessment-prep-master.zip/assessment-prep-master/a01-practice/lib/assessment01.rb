class Array
  def my_inject(accumulator = nil)
  end
end

def is_prime?(num)
end

def primes(count)
end

# the "calls itself recursively" spec may say that there is no method
# named "and_call_original" if you are using an older version of
# rspec. You may ignore this failure.
# Also, be aware that the first factorial number is 0!, which is defined
# to equal 1. So the 2nd factorial is 1!, the 3rd factorial is 2!, etc.
def factorials_rec(num)
end

class Array
  def dups
  end
end

class String
  def symmetric_substrings
  end
end

class Array
  def merge_sort(&prc)
  end

  private
  def self.merge(left, right, &prc)
  end
end
