class Company < ActiveRecord::Base
end
