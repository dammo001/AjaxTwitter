# w6d4: [jQuery Plugins][description]

## Live Solutions!

* [Carousel](http://appacademy.github.io/jQueryPlugins/html/carousel.html)
* [Knob](http://appacademy.github.io/jQueryPlugins/html/knob.html)
* [Tabs](http://appacademy.github.io/jQueryPlugins/html/tabs.html)
* [Thumbnails](http://appacademy.github.io/jQueryPlugins/html/thumbnails.html)
* [Zoomable](http://appacademy.github.io/jQueryPlugins/html/zoomable.html)

[description]: https://github.com/appacademy/js-curriculum/blob/master/projects/w6d4-jquery-plugins.md
